Implementation code for the paper "Triplet-Mamba: Mamba-based architecture for longitudinal representation learning and patient subtyping"
